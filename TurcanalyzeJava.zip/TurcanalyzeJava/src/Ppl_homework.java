/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author binnursoztutar
 */
public class Ppl_homework {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
   // Örnek dosya adı
        String fileName = "example.txt";

        // Örnek dosya içeriği
        String fileContent = "int main() {\n" +
                             "   int a = 10;\n" +
                             "   int b = 20;\n" +
                             "   int sum = a + b;\n" +
                             "   return sum;\n" +
                             "}\n";

}